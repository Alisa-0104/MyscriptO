using System;

namespace DemEX.Model
{
    public static class Variables
    {
        // Текущий авторизованный пользователь (null = гость)
        public static Entities.Users CurrentUser { get; set; }
    }
}
