namespace DemEX.Model
{
    // Класс для отображения заказов в ListView.
    // Используется вместо анонимного типа чтобы можно было обращаться к полям напрямую.
    public class OrderView
    {
        public byte   Id            { get; set; }
        public byte   NumberOrder   { get; set; }
        public string DateOrder     { get; set; }
        public System.DateTime DateDelivery { get; set; }
        public string Status        { get; set; }
        public short  Code          { get; set; }
        public string ClientName    { get; set; }
        public string PickupAddress { get; set; }
    }
}
