using System.Linq;
using System.Windows.Controls;

namespace DemEX.Pages
{
    public partial class pgTovar : Page
    {
        public pgTovar()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            var db = new Entities.ShoseShopEntities1();
            lvTovar.ItemsSource = db.Tovar.ToList();
        }
    }
}
