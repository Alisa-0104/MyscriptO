using DemEX.Model;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace DemEX.Pages
{
    public partial class Auto : Page
    {
        private int _countUnsuccessful = 0;

        public Auto()
        {
            InitializeComponent();
        }

        // Войти как гость — страница товаров без фильтров
        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            Variables.CurrentUser = null;
            (Window.GetWindow(this) as MainWindow)?.SetGuest();
            NavigationService.Navigate(new pgTovar());
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            string login    = tbLogin.Text.Trim();
            string password = pbPass.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин и пароль.", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var db   = new Entities.ShoseShopEntities1();
            var user = System.Linq.Enumerable.FirstOrDefault(
                           db.Users,
                           u => u.Login == login && u.Password == password);

            // Первая попытка — просто проверяем логин и пароль.
            // Если ошиблись — показываем капчу. При второй ошибке — блокируем форму на 10 секунд.
            if (_countUnsuccessful < 1)
            {
                if (user != null)
                {
                    Authorize(user);
                }
                else
                {
                    _countUnsuccessful++;
                    MessageBox.Show("Неверный логин или пароль!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    ShowCaptcha(); // показываем капчу — при следующей попытке нужно её ввести
                }
            }
            else
            {
                // Вторая и последующие попытки — сначала проверяем капчу
                if (tbCaptcha.Text != tblCaptcha.Text) // капча введена неверно — блокируем
                {
                    BlockForm();
                    return;
                }
                if (user != null)
                {
                    Authorize(user);
                }
                else
                {
                    BlockForm();
                }
            }
        }

        private void Authorize(Entities.Users user)
        {
            Variables.CurrentUser = user;
            ClearForm();
            (Window.GetWindow(this) as MainWindow)?.SetLoggedIn();

            switch (user.Role)
            {
                case "Администратор":
                    NavigationService.Navigate(new pgAdmin());
                    break;
                case "Менеджер":
                    NavigationService.Navigate(new pgManager());
                    break;
                default: // Авторизированный клиент
                    NavigationService.Navigate(new pgTovar());
                    break;
            }
        }

        private void ShowCaptcha()
        {
            tblCaptcha.Text       = Model.Captcha.GeneratedCaptcha();
            tblCaptcha.Visibility = Visibility.Visible;
            tbCaptcha.Visibility  = Visibility.Visible;
        }

        private void BlockForm()
        {
            MessageBox.Show("Введите данные заново через 10 секунд!", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);

            // Скрываем капчу и блокируем все поля — пользователь не может ничего вводить
            tblCaptcha.Visibility = Visibility.Collapsed;
            tbCaptcha.Visibility  = Visibility.Collapsed;
            tbLogin.Clear(); tbLogin.IsEnabled   = false;
            pbPass.Clear();  pbPass.IsEnabled    = false;
            btnEnter.IsEnabled = false;
            tbCaptcha.Clear();
            txtBlockTimer.Visibility = Visibility.Visible;

            // Запускаем таймер на 10 секунд — каждую секунду обновляем текст с остатком времени
            Countdown(10, TimeSpan.FromSeconds(1),
                cur => txtBlockTimer.Text = cur + " сек.");
        }

        private void ClearForm()
        {
            tbLogin.Clear(); pbPass.Clear(); tbCaptcha.Clear();
            tblCaptcha.Visibility    = Visibility.Collapsed;
            tbCaptcha.Visibility     = Visibility.Collapsed;
            txtBlockTimer.Visibility = Visibility.Collapsed;
        }

        private void EnableForm()
        {
            tbLogin.IsEnabled  = true;
            pbPass.IsEnabled   = true;
            btnEnter.IsEnabled = true;
            txtBlockTimer.Visibility = Visibility.Collapsed;
            ShowCaptcha();
        }

        // Таймер обратного отсчёта.
        // count    — сколько секунд отсчитывать
        // interval — как часто срабатывать (передаём 1 секунду)
        // tick     — что делать на каждом шаге (обновляем текст с остатком секунд)
        private void Countdown(int count, TimeSpan interval, Action<int> tick)
        {
            var dt = new DispatcherTimer { Interval = interval };
            dt.Tick += (_, __) =>
            {
                if (count-- == 0) { EnableForm(); dt.Stop(); } // время вышло — разблокируем форму
                else tick(count);
            };
            tick(count); // сразу показываем стартовое значение, не ждём первой секунды
            dt.Start();
        }
    }
}
