using DemEX.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DemEX.Pages
{
    public partial class pgAdmin : Page
    {
        private List<Entities.Tovar> _allTovar;

        public pgAdmin()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            var db = new Entities.ShoseShopEntities1();

            // Товары
            _allTovar = db.Tovar.ToList();

            var categories = new[] { "Все категории" }
                .Concat(_allTovar.Select(t => t.TovarCategory).Distinct().OrderBy(c => c))
                .ToList();
            cmbCategory.ItemsSource   = categories;
            cmbCategory.SelectedIndex = 0;

            var suppliers = new[] { "Все поставщики" }
                .Concat(_allTovar.Select(t => t.Supplier).Distinct().OrderBy(s => s))
                .ToList();
            cmbSupplier.ItemsSource   = suppliers;
            cmbSupplier.SelectedIndex = 0;

            ApplyFilter();

            // Заказы
            RefreshOrders(db);
        }

        private void RefreshOrders(Entities.ShoseShopEntities1 db = null)
        {
            if (db == null) db = new Entities.ShoseShopEntities1();

            var orders = db.Orders
                .Include("Users")
                .Include("PickupPoints")
                .ToList()
                .Select(o => new Model.OrderView
                {
                    Id            = o.id,
                    NumberOrder   = o.NumberOrder,
                    DateOrder     = o.DateOrder,
                    DateDelivery  = o.DateDelivery,
                    Status        = o.StateOrder,
                    Code          = o.Code,
                    ClientName    = o.Users.Secondname + " " + o.Users.Firstname + " " + o.Users.Patronomyc,
                    PickupAddress = o.PickupPoints.Index + ", "
                                  + o.PickupPoints.City.Trim() + ", "
                                  + o.PickupPoints.Street.Trim()
                                  + (!o.PickupPoints.Number.HasValue
                                     ? "" : ", " + o.PickupPoints.Number.Value)
                })
                .ToList();

            lvOrders.ItemsSource = orders;
        }

        private void ApplyFilter()
        {
            var result = _allTovar.AsEnumerable();

            var search = tbSearch.Text.Trim().ToLower();
            if (!string.IsNullOrEmpty(search))
                result = result.Where(t =>
                    t.TovarName.ToLower().Contains(search) ||
                    t.Article.ToLower().Contains(search));

            if (cmbCategory.SelectedIndex > 0)
                result = result.Where(t => t.TovarCategory == cmbCategory.SelectedItem.ToString());

            if (cmbSupplier.SelectedIndex > 0)
                result = result.Where(t => t.Supplier == cmbSupplier.SelectedItem.ToString());

            switch (cmbSort.SelectedIndex)
            {
                case 1: result = result.OrderBy(t => t.Price);              break;
                case 2: result = result.OrderByDescending(t => t.Price);    break;
                case 3: result = result.OrderBy(t => t.TovarName);          break;
                case 4: result = result.OrderByDescending(t => t.Discount); break;
            }

            lvTovar.ItemsSource = result.ToList();
        }

        private void Filter_Changed(object sender, RoutedEventArgs e)
        {
            if (_allTovar == null) return;
            ApplyFilter();
        }

        // ===== CRUD ТОВАРОВ =====

        private void btnTovarAdd_Click(object sender, RoutedEventArgs e)
        {
            var wnd = new wndTovarEdit(null);
            if (wnd.ShowDialog() == true)
            {
                _allTovar = new Entities.ShoseShopEntities1().Tovar.ToList();
                ApplyFilter();
            }
        }

        private void btnTovarEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = lvTovar.SelectedItem as Entities.Tovar;
            if (selected == null)
            {
                MessageBox.Show("Выберите товар для редактирования.", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var wnd = new wndTovarEdit(selected);
            if (wnd.ShowDialog() == true)
            {
                _allTovar = new Entities.ShoseShopEntities1().Tovar.ToList();
                ApplyFilter();
            }
        }

        private void btnTovarDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = lvTovar.SelectedItem as Entities.Tovar;
            if (selected == null)
            {
                MessageBox.Show("Выберите товар для удаления.", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var result = MessageBox.Show(
                $"Удалить товар «{selected.TovarName}» (арт. {selected.Article})?",
                "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) return;

            var db   = new Entities.ShoseShopEntities1();
            var item = db.Tovar.Find(selected.id);
            if (item != null)
            {
                db.Tovar.Remove(item);
                db.SaveChanges();
            }
            _allTovar = new Entities.ShoseShopEntities1().Tovar.ToList();
            ApplyFilter();
        }

        // ===== CRUD ЗАКАЗОВ =====

        private void btnOrderAdd_Click(object sender, RoutedEventArgs e)
        {
            var wnd = new wndOrderEdit(null);
            if (wnd.ShowDialog() == true)
                RefreshOrders();
        }

        private void btnOrderEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = lvOrders.SelectedItem;
            if (selected == null)
            {
                MessageBox.Show("Выберите заказ для редактирования.", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var orderView = (Model.OrderView)selected;
            var db        = new Entities.ShoseShopEntities1();
            var order     = db.Orders.Find(orderView.Id);
            var wnd      = new wndOrderEdit(order);
            if (wnd.ShowDialog() == true)
                RefreshOrders();
        }

        private void btnOrderDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = lvOrders.SelectedItem;
            if (selected == null)
            {
                MessageBox.Show("Выберите заказ для удаления.", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var orderView = (Model.OrderView)selected;
            byte orderId  = orderView.Id;
            int  number   = orderView.NumberOrder;

            var confirm = MessageBox.Show($"Удалить заказ №{number}?",
                "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (confirm != MessageBoxResult.Yes) return;

            var db    = new Entities.ShoseShopEntities1();
            var order = db.Orders.Find(orderId);
            if (order != null)
            {
                // Сначала удаляем строки OrderProduct
                var lines = db.OrderProduct.Where(op => op.OrderId == orderId).ToList();
                db.OrderProduct.RemoveRange(lines);
                db.Orders.Remove(order);
                db.SaveChanges();
            }
            RefreshOrders();
        }
    }
}
