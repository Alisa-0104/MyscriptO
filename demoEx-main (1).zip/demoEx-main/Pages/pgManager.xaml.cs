using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace DemEX.Pages
{
    public partial class pgManager : Page
    {
        private List<Entities.Tovar> _allTovar;

        public pgManager()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            var db = new Entities.ShoseShopEntities1();

            // Товары
            _allTovar = db.Tovar.ToList();

            // Заполняем фильтры
            var categories = new[] { "Все категории" }
                .Concat(_allTovar.Select(t => t.TovarCategory).Distinct().OrderBy(c => c))
                .ToList();
            cmbCategory.ItemsSource   = categories;
            cmbCategory.SelectedIndex = 0;

            var suppliers = new[] { "Все поставщики" }
                .Concat(_allTovar.Select(t => t.Supplier).Distinct().OrderBy(s => s))
                .ToList();
            cmbSupplier.ItemsSource   = suppliers;
            cmbSupplier.SelectedIndex = 0;

            ApplyFilter();

            // Заказы — проекция с именем клиента и адресом пункта выдачи
            var orders = db.Orders
                .Include("Users")
                .Include("PickupPoints")
                .ToList()
                .Select(o => new Model.OrderView
                {
                    Id            = o.id,
                    NumberOrder   = o.NumberOrder,
                    DateOrder     = o.DateOrder,
                    DateDelivery  = o.DateDelivery,
                    Status        = o.StateOrder,
                    Code          = o.Code,
                    ClientName    = o.Users.Secondname + " " + o.Users.Firstname + " " + o.Users.Patronomyc,
                    PickupAddress = o.PickupPoints.Index + ", "
                                  + o.PickupPoints.City.Trim() + ", "
                                  + o.PickupPoints.Street.Trim()
                                  + (!o.PickupPoints.Number.HasValue
                                     ? "" : ", " + o.PickupPoints.Number.Value)
                })
                .ToList();

            lvOrders.ItemsSource = orders;
        }

        private void ApplyFilter()
        {
            var result = _allTovar.AsEnumerable();

            // Поиск по наименованию и артикулу
            var search = tbSearch.Text.Trim().ToLower();
            if (!string.IsNullOrEmpty(search))
                result = result.Where(t =>
                    t.TovarName.ToLower().Contains(search) ||
                    t.Article.ToLower().Contains(search));

            // Фильтр по категории
            if (cmbCategory.SelectedIndex > 0)
                result = result.Where(t => t.TovarCategory == cmbCategory.SelectedItem.ToString());

            // Фильтр по поставщику
            if (cmbSupplier.SelectedIndex > 0)
                result = result.Where(t => t.Supplier == cmbSupplier.SelectedItem.ToString());

            // Сортировка
            switch (cmbSort.SelectedIndex)
            {
                case 1: result = result.OrderBy(t => t.Price);           break;
                case 2: result = result.OrderByDescending(t => t.Price); break;
                case 3: result = result.OrderBy(t => t.TovarName);       break;
                case 4: result = result.OrderByDescending(t => t.Discount); break;
            }

            lvTovar.ItemsSource = result.ToList();
        }

        private void Filter_Changed(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_allTovar == null) return;
            ApplyFilter();
        }
    }
}
