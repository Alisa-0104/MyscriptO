USE [master]
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'ShoseShop')
    DROP DATABASE [ShoseShop]
GO

CREATE DATABASE [ShoseShop] COLLATE Cyrillic_General_CI_AS
GO

USE [ShoseShop]
GO

-- =============================================
-- Пользователи (было: user_import)
-- =============================================
CREATE TABLE [dbo].[Users] (
    [Id]         TINYINT      NOT NULL,
    [Role]       NVARCHAR(50) NOT NULL,
    [Firstname]  NVARCHAR(50) NOT NULL,
    [Secondname] NVARCHAR(50) NOT NULL,
    [Patronomyc] NVARCHAR(50) NOT NULL,
    [Login]      NVARCHAR(50) NOT NULL,
    [Password]   NVARCHAR(50) NOT NULL,
    CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED ([Id] ASC)
)
GO

-- =============================================
-- Пункты выдачи (было: Pick-up point_import)
-- =============================================
CREATE TABLE [dbo].[PickupPoints] (
    [id]     TINYINT      NOT NULL,
    [Index]  INT          NOT NULL,
    [City]   NVARCHAR(50) NOT NULL,
    [Street] NVARCHAR(50) NOT NULL,
    [Number] TINYINT      NULL,
    CONSTRAINT [PK_PickupPoints] PRIMARY KEY CLUSTERED ([id] ASC)
)
GO

-- =============================================
-- Товары
-- =============================================
CREATE TABLE [dbo].[Tovar] (
    [id]               TINYINT       NOT NULL,
    [Article]          NVARCHAR(50)  NOT NULL,
    [TovarName]        NVARCHAR(50)  NOT NULL,
    [UnitMeasure]      NVARCHAR(50)  NOT NULL,
    [Price]            SMALLINT      NOT NULL,
    [Supplier]         NVARCHAR(50)  NOT NULL,
    [Creater]          NVARCHAR(50)  NOT NULL,
    [TovarCategory]    NVARCHAR(50)  NOT NULL,
    [Discount]         TINYINT       NOT NULL,
    [CountOnSclad]     TINYINT       NOT NULL,
    [TovarDiscription] NVARCHAR(100) NOT NULL,
    [Photo]            NVARCHAR(50)  NULL,
    CONSTRAINT [PK_Tovar] PRIMARY KEY CLUSTERED ([id] ASC)
)
GO

-- =============================================
-- Заказы (было: order_import)
-- =============================================
CREATE TABLE [dbo].[Orders] (
    [id]             TINYINT      NOT NULL,
    [NumberOrder]    TINYINT      NOT NULL,
    [DateOrder]      NVARCHAR(50) NOT NULL,
    [DateDelivery]   DATE         NOT NULL,
    [AddressPointId] TINYINT      NOT NULL,
    [UserId]         TINYINT      NOT NULL,
    [Code]           SMALLINT     NOT NULL,
    [StateOrder]     NVARCHAR(50) NOT NULL,
    CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_Orders_PickupPoints] FOREIGN KEY ([AddressPointId]) REFERENCES [dbo].[PickupPoints] ([id]),
    CONSTRAINT [FK_Orders_Users]        FOREIGN KEY ([UserId])         REFERENCES [dbo].[Users] ([Id])
)
GO

-- =============================================
-- Товары в заказах
-- =============================================
CREATE TABLE [dbo].[OrderProduct] (
    [id]        TINYINT NOT NULL,
    [OrderId]   TINYINT NOT NULL,
    [ProductId] TINYINT NOT NULL,
    [Count]     TINYINT NOT NULL,
    CONSTRAINT [PK_OrderProduct]        PRIMARY KEY CLUSTERED ([id] ASC),
    CONSTRAINT [FK_OrderProduct_Orders] FOREIGN KEY ([OrderId])   REFERENCES [dbo].[Orders] ([id]),
    CONSTRAINT [FK_OrderProduct_Tovar]  FOREIGN KEY ([ProductId]) REFERENCES [dbo].[Tovar]  ([id])
)
GO

-- =============================================
-- Данные: Users
-- =============================================
INSERT [dbo].[Users] VALUES (1,  N'Администратор',        N'Никифорова', N'Весения',  N'Николаевна',  N'94d5ous@gmail.com',     N'uzWC67')
INSERT [dbo].[Users] VALUES (2,  N'Администратор',        N'Сазонов',    N'Руслан',   N'Германович',  N'uth4iz@mail.com',       N'2L6KZG')
INSERT [dbo].[Users] VALUES (3,  N'Администратор',        N'Одинцов',    N'Серафим',  N'Артёмович',   N'yzls62@outlook.com',    N'JlFRCZ')
INSERT [dbo].[Users] VALUES (4,  N'Менеджер',             N'Степанов',   N'Михаил',   N'Артёмович',   N'1diph5e@tutanota.com',  N'8ntwUp')
INSERT [dbo].[Users] VALUES (5,  N'Менеджер',             N'Ворсин',     N'Петр',     N'Евгеньевич',  N'tjde7c@yahoo.com',      N'YOyhfR')
INSERT [dbo].[Users] VALUES (6,  N'Менеджер',             N'Старикова',  N'Елена',    N'Павловна',    N'wpmrc3do@tutanota.com', N'RSbvHv')
INSERT [dbo].[Users] VALUES (7,  N'Авторизированный клиент', N'Михайлюк', N'Анна',   N'Вячеславовна', N'5d4zbu@tutanota.com',  N'rwVDh9')
INSERT [dbo].[Users] VALUES (8,  N'Авторизированный клиент', N'Ситдикова', N'Елена', N'Анатольевна',  N'ptec8ym@yahoo.com',    N'LdNyos')
INSERT [dbo].[Users] VALUES (9,  N'Авторизированный клиент', N'Ворсин',   N'Петр',   N'Евгеньевич',  N'1qz4kw@mail.com',      N'gynQMT')
INSERT [dbo].[Users] VALUES (10, N'Авторизированный клиент', N'Старикова', N'Елена', N'Павловна',     N'4np6se@mail.com',      N'AtnDjr')
GO

-- =============================================
-- Данные: PickupPoints
-- =============================================
INSERT [dbo].[PickupPoints] VALUES (1,  420151, N'г. Лесной',  N'ул. Вишневая',        32)
INSERT [dbo].[PickupPoints] VALUES (2,  125061, N'г. Лесной',  N'ул. Подгорная',       8)
INSERT [dbo].[PickupPoints] VALUES (3,  630370, N'г. Лесной',  N'ул. Шоссейная',       24)
INSERT [dbo].[PickupPoints] VALUES (4,  400562, N'г. Лесной',  N'ул. Зеленая',         32)
INSERT [dbo].[PickupPoints] VALUES (5,  614510, N'г. Лесной',  N'ул. Маяковского',     47)
INSERT [dbo].[PickupPoints] VALUES (6,  410542, N'г. Лесной',  N'ул. Светлая',         46)
INSERT [dbo].[PickupPoints] VALUES (7,  620839, N'г. Лесной',  N'ул. Цветочная',       8)
INSERT [dbo].[PickupPoints] VALUES (8,  443890, N'г. Лесной',  N'ул. Коммунистическая',1)
INSERT [dbo].[PickupPoints] VALUES (9,  603379, N'г. Лесной',  N'ул. Спортивная',      46)
INSERT [dbo].[PickupPoints] VALUES (10, 603721, N'г. Лесной',  N'ул. Гоголя',          41)
INSERT [dbo].[PickupPoints] VALUES (11, 410172, N'г. Лесной',  N'ул. Северная',        13)
INSERT [dbo].[PickupPoints] VALUES (12, 614611, N'г. Лесной',  N'ул. Молодежная',      50)
INSERT [dbo].[PickupPoints] VALUES (13, 454311, N'г.Лесной',   N'ул. Новая',           19)
INSERT [dbo].[PickupPoints] VALUES (14, 660007, N'г.Лесной',   N'ул. Октябрьская',     19)
INSERT [dbo].[PickupPoints] VALUES (15, 603036, N'г. Лесной',  N'ул. Садовая',         4)
INSERT [dbo].[PickupPoints] VALUES (16, 394060, N'г.Лесной',   N'ул. Фрунзе',          43)
INSERT [dbo].[PickupPoints] VALUES (17, 410661, N'г. Лесной',  N'ул. Школьная',        50)
INSERT [dbo].[PickupPoints] VALUES (18, 625590, N'г. Лесной',  N'ул. Коммунистическая',20)
INSERT [dbo].[PickupPoints] VALUES (19, 625683, N'г. Лесной',  N'ул. 8 Марта',         NULL)
INSERT [dbo].[PickupPoints] VALUES (20, 450983, N'г.Лесной',   N'ул. Комсомольская',   26)
INSERT [dbo].[PickupPoints] VALUES (21, 394782, N'г. Лесной',  N'ул. Чехова',          3)
INSERT [dbo].[PickupPoints] VALUES (22, 603002, N'г. Лесной',  N'ул. Дзержинского',    28)
INSERT [dbo].[PickupPoints] VALUES (23, 450558, N'г. Лесной',  N'ул. Набережная',      30)
INSERT [dbo].[PickupPoints] VALUES (24, 344288, N'г. Лесной',  N'ул. Чехова',          1)
INSERT [dbo].[PickupPoints] VALUES (25, 614164, N'г.Лесной',   N'ул. Степная',         30)
INSERT [dbo].[PickupPoints] VALUES (26, 394242, N'г. Лесной',  N'ул. Коммунистическая',43)
INSERT [dbo].[PickupPoints] VALUES (27, 660540, N'г. Лесной',  N'ул. Солнечная',       25)
INSERT [dbo].[PickupPoints] VALUES (28, 125837, N'г. Лесной',  N'ул. Шоссейная',       40)
INSERT [dbo].[PickupPoints] VALUES (29, 125703, N'г. Лесной',  N'ул. Партизанская',    49)
INSERT [dbo].[PickupPoints] VALUES (30, 625283, N'г. Лесной',  N'ул. Победы',          46)
INSERT [dbo].[PickupPoints] VALUES (31, 614753, N'г. Лесной',  N'ул. Полевая',         35)
INSERT [dbo].[PickupPoints] VALUES (32, 426030, N'г. Лесной',  N'ул. Маяковского',     44)
INSERT [dbo].[PickupPoints] VALUES (33, 450375, N'г. Лесной',  N'ул. Клубная',         44)
INSERT [dbo].[PickupPoints] VALUES (34, 625560, N'г. Лесной',  N'ул. Некрасова',       12)
INSERT [dbo].[PickupPoints] VALUES (35, 630201, N'г. Лесной',  N'ул. Комсомольская',   17)
INSERT [dbo].[PickupPoints] VALUES (36, 190949, N'г. Лесной',  N'ул. Мичурина',        26)
GO

-- =============================================
-- Данные: Tovar
-- =============================================
INSERT [dbo].[Tovar] VALUES (1,  N'А112Т4', N'Ботинки',     N'шт.', 4990,  N'Kari',          N'Kari',         N'Женская обувь', 3,  6,  N'Женские Ботинки демисезонные kari',                                    N'1.jpg')
INSERT [dbo].[Tovar] VALUES (2,  N'F635R4', N'Ботинки',     N'шт.', 3244,  N'Обувь для вас', N'Marco Tozzi',  N'Женская обувь', 2,  13, N'Ботинки Marco Tozzi женские демисезонные, размер 39, цвет бежевый',   N'2.jpg')
INSERT [dbo].[Tovar] VALUES (3,  N'H782T5', N'Туфли',       N'шт.', 4499,  N'Kari',          N'Kari',         N'Мужская обувь', 4,  5,  N'Туфли kari мужские классика MYZ21AW-450A, размер 43, цвет: черный',   N'3.jpg')
INSERT [dbo].[Tovar] VALUES (4,  N'G783F5', N'Ботинки',     N'шт.', 5900,  N'Kari',          N'Рос',          N'Мужская обувь', 2,  8,  N'Мужские ботинки Рос-Обувь кожаные с натуральным мехом',               N'4.jpg')
INSERT [dbo].[Tovar] VALUES (5,  N'J384T6', N'Ботинки',     N'шт.', 3800,  N'Обувь для вас', N'Rieker',       N'Мужская обувь', 2,  16, N'B3430/14 Полуботинки мужские Rieker',                                 N'5.jpg')
INSERT [dbo].[Tovar] VALUES (6,  N'D572U8', N'Кроссовки',   N'шт.', 4100,  N'Обувь для вас', N'Рос',          N'Мужская обувь', 3,  6,  N'129615-4 Кроссовки мужские',                                          N'6.jpg')
INSERT [dbo].[Tovar] VALUES (7,  N'F572H7', N'Туфли',       N'шт.', 2700,  N'Kari',          N'Marco Tozzi',  N'Женская обувь', 2,  14, N'Туфли Marco Tozzi женские летние, размер 39, цвет черный',            N'7.jpg')
INSERT [dbo].[Tovar] VALUES (8,  N'D329H3', N'Полуботинки', N'шт.', 1890,  N'Обувь для вас', N'Alessio Nesca',N'Женская обувь', 4,  4,  N'Полуботинки Alessio Nesca женские 3-30797-47, размер 37, цвет: бордовый', N'8.jpg')
INSERT [dbo].[Tovar] VALUES (9,  N'B320R5', N'Туфли',       N'шт.', 4300,  N'Kari',          N'Rieker',       N'Женская обувь', 2,  6,  N'Туфли Rieker женские демисезонные, размер 41, цвет коричневый',       N'9.jpg')
INSERT [dbo].[Tovar] VALUES (10, N'G432E4', N'Туфли',       N'шт.', 2800,  N'Kari',          N'Kari',         N'Женская обувь', 3,  15, N'Туфли kari женские TR-YR-413017, размер 37, цвет: черный',            N'10.jpg')
INSERT [dbo].[Tovar] VALUES (11, N'S213E3', N'Полуботинки', N'шт.', 2156,  N'Обувь для вас', N'CROSBY',       N'Мужская обувь', 3,  6,  N'407700/01-01 Полуботинки мужские CROSBY',                             NULL)
INSERT [dbo].[Tovar] VALUES (12, N'E482R4', N'Полуботинки', N'шт.', 1800,  N'Kari',          N'Kari',         N'Женская обувь', 2,  14, N'Полуботинки kari женские MYZ20S-149, размер 41, цвет: черный',        NULL)
INSERT [dbo].[Tovar] VALUES (13, N'S634B5', N'Кеды',        N'шт.', 5500,  N'Обувь для вас', N'CROSBY',       N'Мужская обувь', 3,  0,  N'Кеды Caprice мужские демисезонные, размер 42, цвет черный',           NULL)
INSERT [dbo].[Tovar] VALUES (14, N'K345R4', N'Полуботинки', N'шт.', 2100,  N'Обувь для вас', N'CROSBY',       N'Мужская обувь', 2,  3,  N'407700/01-02 Полуботинки мужские CROSBY',                             NULL)
INSERT [dbo].[Tovar] VALUES (15, N'O754F4', N'Туфли',       N'шт.', 5400,  N'Обувь для вас', N'Rieker',       N'Женская обувь', 4,  18, N'Туфли женские демисезонные Rieker артикул 55073-68/37',               NULL)
INSERT [dbo].[Tovar] VALUES (16, N'G531F4', N'Ботинки',     N'шт.', 6600,  N'Kari',          N'Kari',         N'Женская обувь', 12, 9,  N'Ботинки женские зимние ROMER арт. 893167-01 Черный',                  NULL)
INSERT [dbo].[Tovar] VALUES (17, N'J542F5', N'Тапочки',     N'шт.', 500,   N'Kari',          N'Kari',         N'Мужская обувь', 13, 0,  N'Тапочки мужские Арт.70701-55-67син р.41',                             NULL)
INSERT [dbo].[Tovar] VALUES (18, N'B431R5', N'Ботинки',     N'шт.', 2700,  N'Обувь для вас', N'Rieker',       N'Мужская обувь', 2,  5,  N'Мужские кожаные ботинки/мужские ботинки',                            NULL)
INSERT [dbo].[Tovar] VALUES (19, N'P764G4', N'Туфли',       N'шт.', 6800,  N'Kari',          N'CROSBY',       N'Женская обувь', 15, 15, N'Туфли женские, ARGO, размер 38',                                      NULL)
INSERT [dbo].[Tovar] VALUES (20, N'C436G5', N'Ботинки',     N'шт.', 10200, N'Kari',          N'Alessio Nesca',N'Женская обувь', 15, 9,  N'Ботинки женские, ARGO, размер 40',                                    NULL)
INSERT [dbo].[Tovar] VALUES (21, N'F427R5', N'Ботинки',     N'шт.', 11800, N'Обувь для вас', N'Rieker',       N'Женская обувь', 15, 11, N'Ботинки на молнии с декоративной пряжкой FRAU',                       NULL)
INSERT [dbo].[Tovar] VALUES (22, N'N457T5', N'Полуботинки', N'шт.', 4600,  N'Kari',          N'CROSBY',       N'Женская обувь', 3,  13, N'Полуботинки Ботинки черные зимние, мех',                              NULL)
INSERT [dbo].[Tovar] VALUES (23, N'D364R4', N'Туфли',       N'шт.', 12400, N'Kari',          N'Kari',         N'Женская обувь', 16, 5,  N'Туфли Luiza Belly женские Kate-lazo черные из натуральной замши',     NULL)
INSERT [dbo].[Tovar] VALUES (24, N'S326R5', N'Тапочки',     N'шт.', 9900,  N'Обувь для вас', N'CROSBY',       N'Мужская обувь', 17, 15, N'Мужские кожаные тапочки "Профиль С.Дали"',                            NULL)
INSERT [dbo].[Tovar] VALUES (25, N'L754R4', N'Полуботинки', N'шт.', 1700,  N'Kari',          N'Kari',         N'Женская обувь', 2,  7,  N'Полуботинки kari женские WB2020SS-26, размер 38, цвет: черный',       NULL)
INSERT [dbo].[Tovar] VALUES (26, N'M542T5', N'Кроссовки',   N'шт.', 2800,  N'Обувь для вас', N'Rieker',       N'Мужская обувь', 18, 3,  N'Кроссовки мужские TOFA',                                             NULL)
INSERT [dbo].[Tovar] VALUES (27, N'D268G5', N'Туфли',       N'шт.', 4399,  N'Обувь для вас', N'Rieker',       N'Женская обувь', 3,  12, N'Туфли Rieker женские демисезонные, размер 36, цвет коричневый',       NULL)
INSERT [dbo].[Tovar] VALUES (28, N'T324F5', N'Сапоги',      N'шт.', 4699,  N'Kari',          N'CROSBY',       N'Женская обувь', 2,  5,  N'Сапоги замша Цвет: синий',                                            NULL)
INSERT [dbo].[Tovar] VALUES (29, N'K358H6', N'Тапочки',     N'шт.', 599,   N'Kari',          N'Rieker',       N'Мужская обувь', 20, 2,  N'Тапочки мужские син р.41',                                            NULL)
INSERT [dbo].[Tovar] VALUES (30, N'H535R5', N'Ботинки',     N'шт.', 2300,  N'Обувь для вас', N'Rieker',       N'Женская обувь', 2,  7,  N'Женские Ботинки демисезонные',                                        NULL)
GO

-- =============================================
-- Данные: Orders
-- =============================================
INSERT [dbo].[Orders] VALUES (1,  1,  N'27.02.2025', CAST(N'2025-04-20' AS Date), 1,  4, 901, N'Завершен')
INSERT [dbo].[Orders] VALUES (2,  2,  N'28.09.2022', CAST(N'2025-04-21' AS Date), 11, 1, 902, N'Завершен')
INSERT [dbo].[Orders] VALUES (3,  3,  N'21.03.2025', CAST(N'2025-04-22' AS Date), 2,  2, 903, N'Завершен')
INSERT [dbo].[Orders] VALUES (4,  4,  N'20.02.2025', CAST(N'2025-04-23' AS Date), 11, 3, 904, N'Завершен')
INSERT [dbo].[Orders] VALUES (5,  5,  N'17.03.2025', CAST(N'2025-04-24' AS Date), 2,  4, 905, N'Завершен')
INSERT [dbo].[Orders] VALUES (6,  6,  N'01.03.2025', CAST(N'2025-04-25' AS Date), 15, 1, 906, N'Завершен')
INSERT [dbo].[Orders] VALUES (7,  7,  N'30.02.2025', CAST(N'2025-04-26' AS Date), 3,  2, 907, N'Завершен')
INSERT [dbo].[Orders] VALUES (8,  8,  N'31.03.2025', CAST(N'2025-04-27' AS Date), 19, 3, 908, N'Новый')
INSERT [dbo].[Orders] VALUES (9,  9,  N'02.04.2025', CAST(N'2025-04-28' AS Date), 5,  4, 909, N'Новый')
INSERT [dbo].[Orders] VALUES (10, 10, N'03.04.2025', CAST(N'2025-04-29' AS Date), 19, 4, 910, N'Новый')
GO

-- =============================================
-- Данные: OrderProduct
-- =============================================
INSERT [dbo].[OrderProduct] VALUES (1,  1,  1,  2)
INSERT [dbo].[OrderProduct] VALUES (2,  1,  2,  2)
INSERT [dbo].[OrderProduct] VALUES (3,  2,  3,  1)
INSERT [dbo].[OrderProduct] VALUES (4,  2,  4,  1)
INSERT [dbo].[OrderProduct] VALUES (5,  3,  5,  10)
INSERT [dbo].[OrderProduct] VALUES (6,  3,  6,  10)
INSERT [dbo].[OrderProduct] VALUES (7,  4,  7,  5)
INSERT [dbo].[OrderProduct] VALUES (8,  4,  8,  4)
INSERT [dbo].[OrderProduct] VALUES (9,  5,  1,  2)
INSERT [dbo].[OrderProduct] VALUES (10, 5,  2,  2)
INSERT [dbo].[OrderProduct] VALUES (11, 6,  3,  1)
INSERT [dbo].[OrderProduct] VALUES (12, 6,  4,  1)
INSERT [dbo].[OrderProduct] VALUES (13, 7,  5,  10)
INSERT [dbo].[OrderProduct] VALUES (14, 7,  6,  10)
INSERT [dbo].[OrderProduct] VALUES (15, 8,  7,  5)
INSERT [dbo].[OrderProduct] VALUES (16, 8,  8,  4)
INSERT [dbo].[OrderProduct] VALUES (17, 9,  9,  5)
INSERT [dbo].[OrderProduct] VALUES (18, 9,  10, 1)
INSERT [dbo].[OrderProduct] VALUES (19, 10, 11, 5)
INSERT [dbo].[OrderProduct] VALUES (20, 10, 12, 5)
GO

-- =============================================
-- Проверка
-- =============================================
SELECT 'Users'        AS [Таблица], COUNT(*) AS [Строк] FROM [dbo].[Users]
UNION ALL
SELECT 'PickupPoints',               COUNT(*)            FROM [dbo].[PickupPoints]
UNION ALL
SELECT 'Tovar',                      COUNT(*)            FROM [dbo].[Tovar]
UNION ALL
SELECT 'Orders',                     COUNT(*)            FROM [dbo].[Orders]
UNION ALL
SELECT 'OrderProduct',               COUNT(*)            FROM [dbo].[OrderProduct]
GO
