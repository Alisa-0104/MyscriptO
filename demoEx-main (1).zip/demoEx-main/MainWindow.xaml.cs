using DemEX.Pages;
using System.Windows;
using System.Windows.Controls;

namespace DemEX
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            FrmMain.Navigate(new Auto());
        }

        private void btnSignIn_Click(object sender, RoutedEventArgs e)
        {
            FrmMain.Navigate(new Auto());
            btnSignIn.Visibility  = Visibility.Collapsed;
            btnLogout.Visibility  = Visibility.Collapsed;
            btnBack.Visibility    = Visibility.Collapsed;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            if (FrmMain.CanGoBack)
                FrmMain.GoBack();
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            Model.Variables.CurrentUser = null;
            btnLogout.Visibility = Visibility.Collapsed;
            btnBack.Visibility   = Visibility.Collapsed;
            btnSignIn.Visibility = Visibility.Visible;
            FrmMain.Navigate(new Auto());
        }

        // Вызывается из Auto после успешной авторизации
        public void SetLoggedIn()
        {
            btnSignIn.Visibility = Visibility.Collapsed;
            btnLogout.Visibility = Visibility.Visible;
            btnBack.Visibility   = Visibility.Visible;
        }

        // Вызывается из Auto при входе как гость
        public void SetGuest()
        {
            btnSignIn.Visibility = Visibility.Visible;
            btnLogout.Visibility = Visibility.Collapsed;
            btnBack.Visibility   = Visibility.Collapsed;
        }
    }
}
