using System;
using System.Linq;
using System.Windows;

namespace DemEX.Windows
{
    // Вспомогательные классы для ComboBox
    public class UserItem
    {
        public byte   Id       { get; set; }
        public string FullName { get; set; }
    }

    public class PickupItem
    {
        public byte   Id      { get; set; }
        public string Address { get; set; }
    }

    public partial class wndOrderEdit : Window
    {
        private readonly Entities.Orders _order;

        public wndOrderEdit(Entities.Orders order)
        {
            InitializeComponent();
            _order = order;

            var db = new Entities.ShoseShopEntities1();

            // Заполняем список клиентов (только авторизированные клиенты)
            var users = db.Users
                .Where(u => u.Role == "Авторизированный клиент")
                .ToList()
                .Select(u => new UserItem
                {
                    Id       = u.Id,
                    FullName = u.Secondname + " " + u.Firstname + " " + u.Patronomyc
                })
                .ToList();
            cmbUser.DisplayMemberPath = "FullName"; // что показывать в списке
            cmbUser.SelectedValuePath = "Id";       // что считать выбранным значением
            cmbUser.ItemsSource       = users;

            // Заполняем пункты выдачи
            var points = db.PickupPoints.ToList()
                .Select(p => new PickupItem
                {
                    Id      = p.id,
                    Address = p.Index + ", " + p.City.Trim() + ", "
                              + p.Street.Trim()
                              + (!p.Number.HasValue ? "" : ", " + p.Number.Value)
                })
                .ToList();
            cmbPickup.DisplayMemberPath = "Address";
            cmbPickup.SelectedValuePath = "Id";
            cmbPickup.ItemsSource       = points;

            if (order == null)
            {
                tblTitle.Text = "Добавление заказа";
                cmbStatus.SelectedIndex = 0;
            }
            else
            {
                tblTitle.Text      = "Редактирование заказа";
                tbDateOrder.Text   = order.DateOrder;
                dpDelivery.SelectedDate = order.DateDelivery;
                tbCode.Text        = order.Code.ToString();

                // Статус
                var statusItem = cmbStatus.Items.Cast<System.Windows.Controls.ComboBoxItem>()
                    .FirstOrDefault(i => i.Content.ToString() == order.StateOrder.Trim());
                if (statusItem != null) cmbStatus.SelectedItem = statusItem;

                // SelectedValue автоматически найдёт нужный элемент по Id
                cmbUser.SelectedValue   = order.UserId;
                cmbPickup.SelectedValue = order.AddressPointId;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbDateOrder.Text))
            {
                MessageBox.Show("Введите дату заказа.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (dpDelivery.SelectedDate == null)
            {
                MessageBox.Show("Выберите дату доставки.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (cmbUser.SelectedItem == null)
            {
                MessageBox.Show("Выберите клиента.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (cmbPickup.SelectedItem == null)
            {
                MessageBox.Show("Выберите пункт выдачи.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!short.TryParse(tbCode.Text, out short code))
            {
                MessageBox.Show("Код получения должен быть числом.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            byte userId   = (byte)cmbUser.SelectedValue;
            byte pickupId = (byte)cmbPickup.SelectedValue;
            var  status   = ((System.Windows.Controls.ComboBoxItem)cmbStatus.SelectedItem).Content.ToString();

            var db = new Entities.ShoseShopEntities1();

            if (_order == null)
            {
                // Определяем номер нового заказа: берём максимальный из существующих и прибавляем 1.
                // Если заказов ещё нет — начинаем с 1.
                byte nextNumber = db.Orders.Any()
                    ? (byte)(db.Orders.Max(o => o.NumberOrder) + 1)
                    : (byte)1;

                var newOrder = new Entities.Orders
                {
                    NumberOrder    = nextNumber,
                    DateOrder      = tbDateOrder.Text.Trim(),
                    DateDelivery   = dpDelivery.SelectedDate.Value,
                    StateOrder     = status,
                    Code           = code,
                    UserId         = userId,
                    AddressPointId = pickupId
                };
                db.Orders.Add(newOrder);
            }
            else
            {
                var item = db.Orders.Find(_order.id);
                item.DateOrder      = tbDateOrder.Text.Trim();
                item.DateDelivery   = dpDelivery.SelectedDate.Value;
                item.StateOrder     = status;
                item.Code           = code;
                item.UserId         = userId;
                item.AddressPointId = pickupId;
            }

            db.SaveChanges();
            DialogResult = true;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
