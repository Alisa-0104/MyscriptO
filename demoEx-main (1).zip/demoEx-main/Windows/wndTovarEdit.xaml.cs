using System;
using System.Windows;

namespace DemEX.Windows
{
    public partial class wndTovarEdit : Window
    {
        private readonly Entities.Tovar _tovar;

        public wndTovarEdit(Entities.Tovar tovar)
        {
            InitializeComponent();
            _tovar = tovar;

            if (tovar == null)
            {
                tblTitle.Text = "Добавление товара";
            }
            else
            {
                tblTitle.Text          = "Редактирование товара";
                tbArticle.Text         = tovar.Article;
                tbName.Text            = tovar.TovarName;
                cmbCategory.Text       = tovar.TovarCategory;
                tbPrice.Text           = tovar.Price.ToString();
                tbDiscount.Text        = tovar.Discount.ToString();
                tbSupplier.Text        = tovar.Supplier;
                tbManufacturer.Text    = tovar.Creater;
                tbUnit.Text            = tovar.UnitMeasure;
                tbCount.Text           = tovar.CountOnSclad.ToString();
                tbDesc.Text            = tovar.TovarDiscription;
                tbPhoto.Text           = tovar.Photo ?? "";
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (string.IsNullOrWhiteSpace(tbArticle.Text) ||
                string.IsNullOrWhiteSpace(tbName.Text))
            {
                MessageBox.Show("Заполните обязательные поля: Артикул и Наименование.",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!short.TryParse(tbPrice.Text, out short price) || price < 0)
            {
                MessageBox.Show("Введите корректную цену.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!int.TryParse(tbDiscount.Text, out int discount) || discount < 0 || discount > 100)
            {
                MessageBox.Show("Скидка должна быть числом от 0 до 100.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!int.TryParse(tbCount.Text, out int count) || count < 0)
            {
                MessageBox.Show("Введите корректное количество.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var db = new Entities.ShoseShopEntities1();

            if (_tovar == null)
            {
                // Добавление
                var newItem = new Entities.Tovar
                {
                    Article          = tbArticle.Text.Trim(),
                    TovarName        = tbName.Text.Trim(),
                    TovarCategory    = cmbCategory.Text.Trim(),
                    Price            = price,
                    Discount         = (byte)discount,
                    Supplier         = tbSupplier.Text.Trim(),
                    Creater          = tbManufacturer.Text.Trim(),
                    UnitMeasure      = tbUnit.Text.Trim(),
                    CountOnSclad     = (byte)count,
                    TovarDiscription = tbDesc.Text.Trim(),
                    Photo            = string.IsNullOrWhiteSpace(tbPhoto.Text) ? null : tbPhoto.Text.Trim()
                };
                db.Tovar.Add(newItem);
            }
            else
            {
                // Редактирование
                var item = db.Tovar.Find(_tovar.id);
                item.Article          = tbArticle.Text.Trim();
                item.TovarName        = tbName.Text.Trim();
                item.TovarCategory    = cmbCategory.Text.Trim();
                item.Price            = price;
                item.Discount         = (byte)discount;
                item.Supplier         = tbSupplier.Text.Trim();
                item.Creater          = tbManufacturer.Text.Trim();
                item.UnitMeasure      = tbUnit.Text.Trim();
                item.CountOnSclad     = (byte)count;
                item.TovarDiscription = tbDesc.Text.Trim();
                item.Photo            = string.IsNullOrWhiteSpace(tbPhoto.Text) ? null : tbPhoto.Text.Trim();
            }

            db.SaveChanges();
            DialogResult = true;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
