using System;
using System.Globalization;
using System.IO;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace DemEX.Converters
{
    // Этот класс превращает имя файла из базы данных (например "1.jpg") в картинку для отображения.
    // В БД хранится только имя файла, а сами фото лежат в папке Resources проекта.
    public class PhotoConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
                return null; // фото не указано — ничего не показываем
            try
            {
                // Сначала ищем картинку внутри самого приложения (папка Resources добавлена в проект)
                var uri = new Uri($"pack://application:,,,/Resources/{value}", UriKind.Absolute);
                var img = new BitmapImage();
                img.BeginInit();
                img.UriSource   = uri;
                img.CacheOption = BitmapCacheOption.OnLoad;
                img.EndInit();
                return img;
            }
            catch
            {
                // Если не нашли внутри — ищем файл рядом с запущенной программой в папке Resources
                var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", value.ToString());
                if (!File.Exists(path)) return null; // файл не найден — ничего не показываем
                try
                {
                    var img = new BitmapImage();
                    img.BeginInit();
                    img.UriSource   = new Uri(path, UriKind.Absolute);
                    img.CacheOption = BitmapCacheOption.OnLoad;
                    img.EndInit();
                    return img;
                }
                catch { return null; } // файл повреждён — ничего не показываем
            }
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
