using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace DemEX.Converters
{
    // Этот класс меняет цвет фона строки в списке товаров.
    // WPF вызывает его автоматически для каждой строки, передавая значение поля Discount.
    // Если скидка больше 15 — фон зелёный, иначе прозрачный (как обычно).
    public class DiscountConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int d && d > 15)
                return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E8B57")); // зелёный
            return Brushes.Transparent; // без подсветки
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
